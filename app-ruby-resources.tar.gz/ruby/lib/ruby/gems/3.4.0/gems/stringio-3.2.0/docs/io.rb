# The {built-in class for I/O}[https://docs.ruby-lang.org/en/master/IO.html].
class IO
end
