module Test
  module Unit
    VERSION = "3.6.7"
  end
end
