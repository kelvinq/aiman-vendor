# encoding: UTF-8

module TZInfo
  # Modules and classes used by the format 1 version of TZInfo::Data.
  #
  # @private
  module Format1 #:nodoc:
  end
  private_constant :Format1
end
