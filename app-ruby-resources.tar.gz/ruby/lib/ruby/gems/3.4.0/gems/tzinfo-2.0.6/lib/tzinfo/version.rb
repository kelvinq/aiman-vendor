# encoding: UTF-8
# frozen_string_literal: true

module TZInfo
  # The TZInfo version number.
  VERSION = '2.0.6'
end
