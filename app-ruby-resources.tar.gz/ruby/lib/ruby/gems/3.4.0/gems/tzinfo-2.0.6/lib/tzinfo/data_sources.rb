# encoding: UTF-8

module TZInfo
  # {DataSource} implementations and classes used by {DataSource}
  # implementations.
  module DataSources
  end
end
