# encoding: UTF-8

module TZInfo
  # Modules and classes used by the format 2 version of TZInfo::Data.
  #
  # @private
  module Format2 #:nodoc:
  end
  private_constant :Format2
end
