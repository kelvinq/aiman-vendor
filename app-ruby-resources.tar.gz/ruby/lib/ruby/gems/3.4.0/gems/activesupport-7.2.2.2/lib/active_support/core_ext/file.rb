# frozen_string_literal: true

require "active_support/core_ext/file/atomic"
