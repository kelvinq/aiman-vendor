# frozen_string_literal: true

require "active_support/core_ext/class/attribute"
require "active_support/core_ext/class/subclasses"
