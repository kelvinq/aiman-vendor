# frozen_string_literal: true

require "active_support/core_ext/digest/uuid"
