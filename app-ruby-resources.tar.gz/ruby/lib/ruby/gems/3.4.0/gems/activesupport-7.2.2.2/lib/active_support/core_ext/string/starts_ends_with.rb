# frozen_string_literal: true

class String
  alias :starts_with? :start_with?
  alias :ends_with? :end_with?
end
