# frozen_string_literal: true

require "minitest"

Minitest.autorun
