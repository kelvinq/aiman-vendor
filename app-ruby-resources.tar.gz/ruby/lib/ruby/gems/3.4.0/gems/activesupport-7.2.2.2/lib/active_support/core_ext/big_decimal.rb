# frozen_string_literal: true

require "active_support/core_ext/big_decimal/conversions"
