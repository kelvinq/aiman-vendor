# frozen_string_literal: true

require "active_support/core_ext/pathname/blank"
require "active_support/core_ext/pathname/existence"
