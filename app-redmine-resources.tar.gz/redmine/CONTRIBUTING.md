Your contributions to Redmine are welcome!

Please **open an issue on the [official website]** instead of sending pull requests.

Since the development of Redmine is not conducted on GitHub but on the [official website] and core developers are not monitoring the GitHub repo, pull requests might not get reviewed.

For more detail about how to contribute, please see the wiki page [Contribute] on the [official website].

[official website]: https://www.redmine.org/
[Contribute]: https://www.redmine.org/projects/redmine/wiki/Contribute
